PokeRPG initial assets

Recommended Godot paths:
- Copy pokerpg_assets/assets/ into res://assets/
- Copy screen_mockups/ only as visual reference if wanted.
- Use assets/android/app_icon_512.png as the project icon.
- For Android export, use icon_main_432.png, adaptive_background_432.png and adaptive_foreground_432.png.

Base UI resolution: 360x640 portrait.
All files are PNG placeholders created for the private remake prototype.
